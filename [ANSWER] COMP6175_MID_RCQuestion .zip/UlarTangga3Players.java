package FionaVarenciaTendio;

public class UlarTangga3Players extends UlarTangga{
	private int Old3;
	private int Dice3;
	private int New3;
	public UlarTangga3Players(int old1, int old2, int dice1, int dice2, int new1, int new2, int old3, int dice3,
			int new3) {
		super(old1, old2, dice1, dice2, new1, new2);
		Old3 = old3;
		Dice3 = dice3;
		New3 = new3;
	}
	public int getOld3() {
		return Old3;
	}
	public void setOld3(int old3) {
		Old3 = old3;
	}
	public int getDice3() {
		return Dice3;
	}
	public void setDice3(int dice3) {
		Dice3 = dice3;
	}
	public int getNew3() {
		return New3;
	}
	public void setNew3(int new3) {
		New3 = new3;
	}
}
