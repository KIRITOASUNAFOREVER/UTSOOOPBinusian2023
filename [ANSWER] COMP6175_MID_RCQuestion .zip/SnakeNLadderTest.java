package FionaVarenciaTendio;

import java.util.Random;
import java.util.Scanner;
import java.util.Vector;

public class SnakeNLadderTest {
	Scanner scan  = new Scanner(System.in);
	Vector<UlarTangga>SnakeLadder = new Vector<>();
	Vector<UlarTangga3Players>LadderSnake = new Vector<>();
	Random rand1 = new Random();
	Random rand2 = new Random();
	Random rand3 = new Random();
	
	void mode2Players()
	{
		int round = 1;
		int dadu1,dadu2;
		int count = 0;
		int old1  = 0;
		int old2  = 0;
		int new1  = 0;
		int new2  = 0;
		int hasil = 0;
		int hasil2 = 0;
		
		do{
			System.out.println();
			System.out.println("Giliran Orang Pertama");
			System.out.println("Tekan Enter untuk Roll Dadu");
			scan.nextLine();
			dadu1 = rand1.nextInt(6) + 1;
			System.out.println("Hasil Dadu : "+dadu1);
			System.out.println();
			System.out.println("Giliran Orang Kedua");
			System.out.println("Tekan Enter untuk Roll Dadu");
			scan.nextLine();
			dadu2 = rand2.nextInt(6) + 1;
			System.out.println("Hasil Dadu : "+dadu2);
			if(count==0)
			{
				new1 = old1 + dadu1;
				new2 = old2 + dadu2;
				SnakeLadder.add(new UlarTangga(old1, old2, dadu1, dadu2, new1, new2));
				count = count + 1;
			}
			else
			{
				old1 = SnakeLadder.get(count-1).getNew1();
				old2 = SnakeLadder.get(count-1).getNew2();
				new1 = old1 + dadu1;
				new2 = old2 + dadu2;
				if(new1 == 13)
				{
					new1 = 7;
				}
				if(new2 == 13)
				{
					new2 = 7;
				}
				if(new1 == 25)
				{
					new1 = 40;
				}
				if(new2 == 25)
				{
					new2 = 40;
				}
				if(new1==50)
				{
					new1 = 38;
				}
				if(new2 == 50)
				{
					new2 = 38;
				}
				if(new1 == 63)
				{
					new1 = 78;
				}
				if(new2 == 63)
				{
					new2 = 78;
				}
				if(new1 == 83)
				{
					new1 = 97;
				}
				if(new2== 83)
				{
					new2 = 97;
				}
				if(new1 == 95)
				{
					new1 = 76;
				}
				if(new2 == 95)
				{
					new2 = 76;
				}
				
				if(new1 > 100)
				{
					new1 = 100 - (new1-100);
				}
				if(new2 > 100)
				{
					new2 = 100 - (new2-100);
				}
				SnakeLadder.add(new UlarTangga(old1, old2, dadu1, dadu2, new1, new2));
				count = count + 1;
			}
			System.out.println("        ===========================================================");
			System.out.println("        |     Player A      |     Player B     |     Player C     |");
			System.out.println("===================================================================");
			System.out.printf("| %5s | %-3s | %-4s | %3s  | %3s | %4s | %3s | %3s | %4s | %3s |\n","Round","Old","Dice","New","Old","Dice","New","Old","Dice","New");
			System.out.println("===================================================================");
			for(int i=0; i < SnakeLadder.size(); i++)
			{	
				System.out.printf("|   %-2d  |%3d  | %3d  |%3d   |%3d  | %3d  |%3d  |      |     |     |\n",i+1,SnakeLadder.get(i).getOld1(),SnakeLadder.get(i).getDice1(),SnakeLadder.get(i).getNew1(),SnakeLadder.get(i).getOld2(),SnakeLadder.get(i).getDice2(),SnakeLadder.get(i).getNew2());
				
				System.out.println("===================================================================");
				
			}
			hasil = SnakeLadder.get(SnakeLadder.size()-1).getNew1();
			hasil2 = SnakeLadder.get(SnakeLadder.size()-1).getNew2();
			if(round==25 && hasil!=100 && hasil2!=100)
			{
				if(hasil < hasil2)
				{
					System.out.println("Pemenang "+"1"+" : "+"Player B ("+hasil2+")");
					System.out.println("Pemenang "+"2"+" : "+"Player A ("+hasil+")");
				}
				if(hasil2 < hasil)
				{
					System.out.println("Pemenang "+"1"+" : "+"Player A ("+hasil+")");
					System.out.println("Pemenang "+"2"+" : "+"Player B ("+hasil2+")");
				}
				SnakeLadder.removeAll(SnakeLadder);
			}
			if(round<25 && hasil==100 && hasil2!=100)
			{
				System.out.println("Pemenang "+"1"+" : "+"Player A ("+hasil+")");
				System.out.println("Pemenang "+"2"+" : "+"Player B ("+hasil2+")");
				SnakeLadder.removeAll(SnakeLadder);
				 break;
			}
			if(round<25 && hasil!=100 && hasil2==100)
			{
				System.out.println("Pemenang "+"1"+" : "+"Player B ("+hasil2+")");
				System.out.println("Pemenang "+"2"+" : "+"Player A ("+hasil+")");
				SnakeLadder.removeAll(SnakeLadder);
				break;
			}
			if(round==25 && hasil==100 && hasil==100)
			{
				System.out.println("Karena Player A Kocok Dadu Duluan, Maka Hasil Pemenangnya : ");
				System.out.println("Pemenang "+"1"+" : "+"Player A ("+hasil+")");
				System.out.println("Pemenang "+"2"+" : "+"Player B ("+hasil2+")");
				SnakeLadder.removeAll(SnakeLadder);
				break;
			}
			
			round = round + 1;
		}while(round<=25 && (hasil!=100 || hasil2 !=100));
		
	}
	
	void mode3Players()
	{
		int round = 1;
		int dadu1,dadu2,dadu3;
		int count = 0;
		int old1  = 0;
		int old2  = 0;
		int old3 = 0;
		int new1  = 0;
		int new2  = 0;
		int new3 = 0;
		int hasil = 0;
		int hasil2 = 0;
		int hasil3 = 0;
		
		do{
			System.out.println();
			System.out.println("Giliran Orang Pertama");
			System.out.println("Tekan Enter untuk Roll Dadu");
			scan.nextLine();
			dadu1 = rand1.nextInt(6) + 1;
			System.out.println("Hasil Dadu : "+dadu1);
			System.out.println();
			System.out.println("Giliran Orang Kedua");
			System.out.println("Tekan Enter untuk Roll Dadu");
			scan.nextLine();
			dadu2 = rand2.nextInt(6) + 1;
			System.out.println("Hasil Dadu : "+dadu2);
			System.out.println("Giliran Orang Ketiga");
			System.out.println("Tekan Enter untuk Roll Dadu");
			scan.nextLine();
			dadu3 = rand3.nextInt(6) + 1;
			System.out.println("Hasil Dadu : "+dadu3);
			if(count==0)
			{
				new1 = old1 + dadu1;
				new2 = old2 + dadu2;
				new3 = old3 + dadu3;
				LadderSnake.add(new UlarTangga3Players(old1, old2, dadu1, dadu2, new1, new2, old3, dadu3, new3));
				count = count + 1;
			}
			else
			{
				old1 = LadderSnake.get(count-1).getNew3();
				old2 = LadderSnake.get(count-1).getNew2();
				old3 = LadderSnake.get(count-1).getNew3();
				new1 = old1 + dadu1;
				new2 = old2 + dadu2;
				new3 = old3 + dadu3;
				if(new1 == 13)
				{
					new1 = 7;
				}
				if(new2 == 13)
				{
					new2 = 7;
				}
				if(new3 == 13)
				{
					new3 = 7;
				}
				if(new1 == 25)
				{
					new1 = 40;
				}
				if(new2 == 25)
				{
					new2 = 40;
				}
				if(new3 == 25)
				{
					new3 = 40;
				}
				if(new1==50)
				{
					new1 = 38;
				}
				if(new2 == 50)
				{
					new2 = 38;
				}
				if(new3==50)
				{
					new3 = 38;
				}
				if(new1 == 63)
				{
					new1 = 78;
				}
				if(new2 == 63)
				{
					new2 = 78;
				}
				if(new3 == 63)
				{
					new3 = 78;
				}
				if(new1 == 83)
				{
					new1 = 97;
				}
				if(new2== 83)
				{
					new2 = 97;
				}
				if(new3 == 83)
				{
					new3 = 97;
				}
				if(new1 == 95)
				{
					new1 = 76;
				}
				if(new2 == 95)
				{
					new2 = 76;
				}
				if(new3 == 95)
				{
					new3 = 76;
				}
				if(new1 > 100)
				{
					new1 = 100 - (new1-100);
				}
				if(new2 > 100)
				{
					new2 = 100 - (new2-100);
				}
				if(new3 > 100)
				{
					new3 = 100 - (new3-100);
				}
				LadderSnake.add(new UlarTangga3Players(old1, old2, dadu1, dadu2, new1, new2, old3, dadu3, new3));
				count = count + 1;
			}
			System.out.println("        ===========================================================");
			System.out.println("        |     Player A      |     Player B     |     Player C     |");
			System.out.println("===================================================================");
			System.out.printf("| %5s | %-3s | %-4s | %3s  | %3s | %4s | %3s | %3s | %4s | %3s |\n","Round","Old","Dice","New","Old","Dice","New","Old","Dice","New");
			System.out.println("===================================================================");
			for(int i=0; i < LadderSnake.size(); i++)
			{	
				System.out.printf("|   %-2d  |%3d  | %3d  |%3d   |%3d  | %3d  |%3d  |%3d  |%3d   |%3d  |\n",i+1,LadderSnake.get(i).getOld1(),LadderSnake.get(i).getDice1(),LadderSnake.get(i).getNew1(),LadderSnake.get(i).getOld2(),LadderSnake.get(i).getDice2(),LadderSnake.get(i).getNew2(),LadderSnake.get(i).getOld3(),LadderSnake.get(i).getDice3(),LadderSnake.get(i).getNew3());
				
				System.out.println("===================================================================");
				
			}
			hasil = LadderSnake.get(LadderSnake.size()-1).getNew1();
			hasil2 = LadderSnake.get(LadderSnake.size()-1).getNew2();
			hasil3 = LadderSnake.get(LadderSnake.size()-1).getNew3();
			if(round==25 && hasil!=100 && hasil2!=100 && hasil3!=100)
			{
				if(hasil > hasil2 && hasil > hasil3)
				{
					if(hasil2 > hasil3)
					{
						System.out.println("Pemenang "+"1"+" : "+"Player A ("+hasil+")");
						System.out.println("Pemenang "+"2"+" : "+"Player B ("+hasil2+")");
						System.out.println("Pemenang "+"3"+" : "+"Player C ("+hasil3+")");
					}
					else
					{
						System.out.println("Pemenang "+"1"+" : "+"Player A ("+hasil+")");
						System.out.println("Pemenang "+"2"+" : "+"Player C ("+hasil3+")");
						System.out.println("Pemenang "+"3"+" : "+"Player B ("+hasil2+")");
					}
				}
				else if(hasil2 > hasil && hasil2 > hasil3)
				{
					if(hasil > hasil3)
					{
						System.out.println("Pemenang "+"1"+" : "+"Player B ("+hasil2+")");
						System.out.println("Pemenang "+"2"+" : "+"Player A ("+hasil+")");
						System.out.println("Pemenang "+"3"+" : "+"Player C ("+hasil3+")");
					}
					else
					{
						System.out.println("Pemenang "+"1"+" : "+"Player B ("+hasil2+")");
						System.out.println("Pemenang "+"2"+" : "+"Player C ("+hasil3+")");
						System.out.println("Pemenang "+"3"+" : "+"Player A ("+hasil+")");
					}
				}
				else if(hasil3 > hasil && hasil3 > hasil2)
				{
					if(hasil > hasil2)
					{
						System.out.println("Pemenang "+"1"+" : "+"Player C ("+hasil3+")");
						System.out.println("Pemenang "+"2"+" : "+"Player A ("+hasil+")");
						System.out.println("Pemenang "+"3"+" : "+"Player B ("+hasil2+")");
					}
					else
					{
						System.out.println("Pemenang "+"1"+" : "+"Player C ("+hasil3+")");
						System.out.println("Pemenang "+"2"+" : "+"Player B ("+hasil2+")");
						System.out.println("Pemenang "+"3"+" : "+"Player A ("+hasil+")");
					}
				}
				LadderSnake.removeAll(LadderSnake);
			}
			if(round<25 && hasil==100 && hasil2!=100 && hasil3!=100)
			{
				if(hasil2 > hasil3)
				{
					System.out.println("Pemenang "+"1"+" : "+"Player A ("+hasil+")");
					System.out.println("Pemenang "+"2"+" : "+"Player B ("+hasil2+")");
					System.out.println("Pemenang "+"3"+" : "+"Player C ("+hasil3+")");
				}
				else
				{
					System.out.println("Pemenang "+"1"+" : "+"Player A ("+hasil+")");
					System.out.println("Pemenang "+"2"+" : "+"Player C ("+hasil3+")");
					System.out.println("Pemenang "+"3"+" : "+"Player B ("+hasil2+")");
				}
				LadderSnake.removeAll(LadderSnake);
				 break;
			}
			if(round<25 && hasil!=100 && hasil2==100 && hasil3!=100)
			{
				if(hasil > hasil3)
				{
					System.out.println("Pemenang "+"1"+" : "+"Player B ("+hasil2+")");
					System.out.println("Pemenang "+"2"+" : "+"Player A ("+hasil+")");
					System.out.println("Pemenang "+"3"+" : "+"Player C ("+hasil3+")");
				}
				else
				{
					System.out.println("Pemenang "+"1"+" : "+"Player B ("+hasil2+")");
					System.out.println("Pemenang "+"2"+" : "+"Player C ("+hasil3+")");
					System.out.println("Pemenang "+"3"+" : "+"Player A ("+hasil+")");
				}
				LadderSnake.removeAll(LadderSnake);
				break;
			}
			if(round < 25 && hasil!=100 &&hasil2!=100 && hasil==100)
			{
				if(hasil > hasil2)
				{
					System.out.println("Pemenang "+"1"+" : "+"Player C ("+hasil3+")");
					System.out.println("Pemenang "+"2"+" : "+"Player A ("+hasil+")");
					System.out.println("Pemenang "+"3"+" : "+"Player B ("+hasil2+")");
				}
				else
				{
					System.out.println("Pemenang "+"1"+" : "+"Player C ("+hasil3+")");
					System.out.println("Pemenang "+"2"+" : "+"Player B ("+hasil2+")");
					System.out.println("Pemenang "+"3"+" : "+"Player A ("+hasil+")");
				}
				LadderSnake.removeAll(LadderSnake);
			}
			if(round==25 && hasil==100 && hasil==100 && hasil==100)
			{
				System.out.println("Karena Player A Kocok Dadu Duluan, Setelah itu Player B, Maka Hasil Pemenangnya : ");
				if(hasil2 > hasil3)
				{
					System.out.println("Pemenang "+"1"+" : "+"Player A ("+hasil+")");
					System.out.println("Pemenang "+"2"+" : "+"Player B ("+hasil2+")");
					System.out.println("Pemenang "+"3"+" : "+"Player C ("+hasil3+")");
				}
				LadderSnake.removeAll(LadderSnake);
				break;
			}
			round = round + 1;
		}while(round<=25 && (hasil!=100 || hasil2 !=100));
	}
	
	public SnakeNLadderTest()
	{
		int choose;
		
		do{
			System.out.println("Snakes Ladders Menu:");
			System.out.println("1. 2 Players Mode");
			System.out.println("2. 3 Players Mode");
			System.out.println("3. Exit");
			System.out.print("Pilih Menu : ");
			choose = scan.nextInt();scan.nextLine();
			
			switch(choose)
			{
			case 1:
				mode2Players();
				break;
			case 2:
				mode3Players();
				break;
			}
			System.out.println();
		}while(choose > 3 || choose < 1 || choose!=3);
	}
	
	public static void main(String[] args) {
		new SnakeNLadderTest();
	}
}