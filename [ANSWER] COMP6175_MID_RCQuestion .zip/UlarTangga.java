package FionaVarenciaTendio;

public class UlarTangga {
	private int Old1;
	private int Old2;
	private int Dice1;
	private int Dice2;
	private int New1;
	private int New2;
	
	public UlarTangga(int old1, int old2, int dice1, int dice2, int new1, int new2) {
		
		Old1 = old1;
		Old2 = old2;
		Dice1 = dice1;
		Dice2 = dice2;
		New1 = new1;
		New2 = new2;
	}

	public int getOld1() {
		return Old1;
	}

	public void setOld1(int old1) {
		Old1 = old1;
	}

	public int getOld2() {
		return Old2;
	}

	public void setOld2(int old2) {
		Old2 = old2;
	}

	public int getDice1() {
		return Dice1;
	}

	public void setDice1(int dice1) {
		Dice1 = dice1;
	}

	public int getDice2() {
		return Dice2;
	}

	public void setDice2(int dice2) {
		Dice2 = dice2;
	}

	public int getNew1() {
		return New1;
	}

	public void setNew1(int new1) {
		New1 = new1;
	}

	public int getNew2() {
		return New2;
	}

	public void setNew2(int new2) {
		New2 = new2;
	}
}
